Releases Notes
##############

.. raw:: html

   <marquee><B>MoilApps Version 4.0 - 2023</B></marquee>

We are excited to announce the release of our desktop app! This release includes the following features:

    - User-friendly interface with intuitive navigation

    - Integrated dark theme that users can use when adding new apps

    - Applications that can be run independently

    - Ability to switch branches through the interface

    - Support for various information in image processing such as username, processing time, camera parameters, and media path loaded

    - Automatic saving of changes made to exportable HTML and PDF documents

    - Functionality for easy revision of commits on the branch

    - Integration with storage service Anypoint image, Panorama image in computer directory

    - Screen Recording that can help users

We have also made some bug fixes and performance improvements to ensure a smoother experience for our users.

Thank you for using our app! If you encounter any issues or have any suggestions for future updates, please feel free to contact us.
