MoilApp Usage
#############

In this session we will explain the components in the MoilApp application and tutorials on how to use the application.

.. figure:: moil-usage/user-operation.png
   :scale: 55 %
   :alt: alternate text
   :align: center

   Operation of MoilApp

Overview of The User Interface
===============================

When you open a project in PyCharm, the default user interface looks as follows:

.. figure:: moil-usage/overview-user.png
   :scale: 60 %
   :alt: alternate text
   :align: center

   Main window Moilapp

Here is detail explanation

1. Open media source
********************

MoilApp provides various sources that can be used for processing, including image files, video files, and cameras both USB cams, web cams or streaming cams from raspberry-pi. You only need to press the button according to the media source that you will process and the app will open a file explorer dialog like shown below.

.. figure:: moil-usage/open-image.png
   :scale: 60 %
   :alt: alternate text
   :align: center

   Open Media Source

.. figure:: moil-usage/select-media-source.png
   :scale: 65 %
   :alt: alternate text
   :align: center

   Select Media Source

- If you open a video file, you will be asked to choose the type of camera used at the combo box prompt after select file. This is useful for loading the camera parameters from the database.

- To open the camera, there are options, namely usb cam and streaming cam. for USB cameras, you can detect the port to find out which port is used and then select it in the combo box, click button “oke” and you will be asked to choose the type of camera used at the combo box prompt. as shown in the image below

- streaming cam option is to open camera from stream server URL which is usually used to access raspberry-pi camera. you only need to provide the URL of the camera and press button “oke” like the example below. you will be asked to choose the type of camera used at the combo box prompt.

2. Rotate Image
************

Moilapp has two rotates namely rotate left image and rotate right image. Each rotate image can be operated by entering a value on the rotate scala, this is so that users can rotate with less scala.

.. figure:: moil-usage/rotate-image.png
   :scale: 60 %
   :alt: alternate text
   :align: center

   Processing Rotate left & Rotate right Image

3. Zoom Image
***********

There are two zoom operations in this application, first the user can use the plus button to zoom out, and the minus button to zoom in, besides that the user can also set the zoom scale to be smaller with a minimum of 25 degrees and greater to clarify the resulting image

.. figure:: moil-usage/zoom-image.png
   :scale: 60 %
   :alt: alternate text
   :align: center

   Processing Zoom in & Zoom out Image

4. Default Application
*******************

When the user is processing an image, for example, is processing an image to any point, suddenly the user wants to return to the original image where this position is the position when the user loads the image when opening the application, then by clicking the default button the application automatically returns to the original image

.. figure:: moil-usage/default.png
   :scale: 60 %
   :alt: alternate text
   :align: center

   Processing default image to original

5. Add Plugin Application
**********************

When the user wants to create an application integrated with MoilApp or the user wants to open the application, the user can add the application to MoilApps by clicking the Add button at the top of the application, provided that the user creates the application using MoilDev or MoilUtils-Templates.

.. figure:: moil-usage/add-plugin-apps.png
   :scale: 60 %
   :alt: alternate text
   :align: center

   Add application

6. Information Applications
************************

As information for users to view related information on moilapp.

.. figure:: moil-usage/information-apps.png
   :scale: 65 %
   :alt: alternate text
   :align: center

   Notice Application

7. About US
************************

Just to inform users to view related information in the field of fisheye image processing research.

.. figure:: moil-usage/about-us.png
   :scale: 75 %
   :alt: alternate text
   :align: center

   Information About US

8. Theme Application
******************

Moilapp provides two themes for use, first with light mode and secondly dark mode, these two themes help users adjust to the user's eyes and also function so that they don't look boring when using this application.

.. figure:: moil-usage/theme-apps.png
   :scale: 65 %
   :alt: alternate text
   :align: center

   Light theme & Dark Theme application

9. Hide Button Application
***********************

Users can also hide or display the title on the button by pressing the "ESC" key on the keyboard or to see the function of the button in the application.

.. figure:: moil-usage/hide-apps.png
   :scale: 80 %
   :alt: alternate text
   :align: center

   Show/Hide button application

10. Fisheye View
*************************

If everything goes properly, the user interface will display the image as shown below.

.. figure:: moil-usage/image-frame.png
   :scale: 35 %
   :alt: alternate text
   :align: center

   Show Image from Directory Computer

For media from video and camera we provide controllers such as play, pause, stop, forward, backward and slider timer. where this controller can be used to facilitate image processing.

11. Anypoint View
*************************

To improve the results of observations, sometimes we only want to see areas that have a lot of information. Therefore, we can use the undistortion rectilinear selected image method. This method is convert the image plane coordinate to hemispherical coordinates, move the optical axis to the specified zenithal (alpha) and azimuthal (beta) angle [refer to section 1.2].

Anypoint view has 2 modes, where mode 1 is the result rotation from betaOffset degree rotation around the Z-axis(roll) after alphaOffset degree rotation around the X-axis(pitch). Whereas, for mode -2 the result rotation is thetaY degree rotation around the Y- axis(yaw) after thetaX degree rotation around the X-axis(pitch).

.. figure:: moil-usage/anypoint-image.png
   :scale: 50 %
   :alt: alternate text
   :align: center

   Processing Anypoint Image

When you are in Anypoint view mode, you can activate the help button which functions to change from mode 1 to mode 2 or vice versa. This help button also functions to see Anypoint result from a predetermined direction. Below is an overview of the extra button in Anypoint view mode

12. Panorama view
*************************

As explained earlier, the panorama view may present a horizontal view in a specific immersed environment to meet the common human visual perception. The Figure below shows a diagram of transforming a fisheye image into a panoramic view.

.. figure:: assets/diagram.jpg
   :scale: 100 %
   :alt: alternate text
   :align: center

   Diagram processing Original View to Panorama View

The image below is the result of image processing panorama view.

.. figure:: moil-usage/panorama-image.png
   :scale: 50 %
   :alt: alternate text
   :align: center

   Processing Panorama View

- You can also change the values of the maximum and minimum FoV via lineedit which will only appear in this mode. The overview of the line edit can be seen in the picture below:

- You can save the original image or result image by pressing the save image button or by right clicking the mouse on the result image and selecting save image. at the first time you will save the image, application will open dialog to directed to choose the directory will use as storage.

- If you want to record a video you can press the record button, the process is almost the same as saving an image. before starting recording, you will be directed to choose a directory and the video files will be saved in that folder.

13. Camera parameters
*****************

Camera parameter is a very important component in fisheye image processing. Each fisheye camera can be calibrated and derives a set of parameters by MOIL laboratory before the successive functions can work correctly, configuration is necessary at the beginning of the program. MoilApp provides a form dialog that can add, modify, and delete parameters that will be stored in the database. To be able to use this feature, please click on File >> Camera Parameters. The overview of this form shown like picture below:

.. figure:: moil-usage/cam-params.png
   :scale: 70 %
   :alt: alternate text
   :align: center

   Camera Parameters

- If you want to see the parameter, you can list the camera type from comboBox list parameter

- If you are using a camera whose parameters are not yet available in the database, you can add them. you just need to write all the parameters on the form, then click the "new" button. after that the data will be saved and you can use the camera parameters.

- Modify camera parameters

- If you want to change the value of the parameter, you can modify it. select the camera type in the list parameter combobox, then you enter the new parameter value. click the update button and the modified parameters will be saved in the database.

- You can also delete parameters by pressing the delete button on the selected parameter list.

14. Clear User Interface (UI)
*************************

Clear UI is the latest feature from Moilapp, where this feature is used to clean images on the user interface, usually if you don't use Clear UI, when the user opens the application again, the user is faced with the previous task when processing images, therefore this feature is used to clear data on the user interface.

.. figure:: moil-usage/clear-apps.png
   :scale: 70 %
   :alt: alternate text
   :align: center

   Clear data on application

15. Check for Updating
*******************

Check for updating is an additional feature of the moilapp update, this feature is used if the user wants to update the application from the developer server. The use of this feature greatly facilitates the user without having to open a terminal to do the installation or update manually.

.. figure:: moil-usage/check-update.png
   :scale: 70 %
   :alt: alternate text
   :align: center

   Check updating application from main server

16. Read the Docs Application
*****************************

Read the docs is application documentation that helps users understand every feature of moilapp, with this feature it's also easy for users to open documents without having to open a terminal and generate an html file by simply clicking on this feature the application will automatically generate documents and display to application users.

.. figure:: moil-usage/docs-spinx.png
   :scale: 70 %
   :alt: alternate text
   :align: center

   Generate documents to html

17. Help Information
********************

18. Apps Setting
****************

In addition to allowing users to review the update history of each commit made by the developer when the application is updated, application settings are used to access setting information on applications.

.. figure:: moil-usage/apps-setting.png
   :scale: 70 %
   :alt: alternate text
   :align: center

   Generate documents to html

Mouse event
===========

There are several functions of the mouse event that you can use to speed up work. The mouse event will only work on the result image and the original image of the user interface widget. Some of the mouse event's functions including

- Mouse click event

Mouse click event works only on the original image widget when Anypoint mode. This handy determine the coordinates of points that will be converted to alpha beta value. which then this value will be a parameter in converting the original image to Anypoint image.

- Mouse press-move event

The mouse press event has its own function in each image widget, in the origina image this widget works in Anypoint mode which allows for surrounding views. Different functions if you press the press-move mouse event on the result image widget, you can enlarge the area you are interested in using this function and its work in all mode view, for the example shown in the image below:

- Double click event

The Double click mouse event has function to reset Anypoint view to default in Anypoint mode.

- Right click event

If you right click on the mouse, it will display menu options like maximized, minimized, save image and show info.

- Mouse wheel

wheel event will work by pressing the ctrl key simultaneously to zoom in and zoom out images on the user interface display

MoilApp keyboard shortcut
=========================

MoilApp has keyboard shortcuts for most of its commands related to processing and other tasks. Memorizing these hotkeys can help you stay more productive by keeping your hands on the keyboard. The following table lists some of the most useful shortcuts to learn:

.. figure:: assets/shortcut.jpg
   :scale: 70 %
   :alt: alternate text
   :align: center

   Shortcut application

