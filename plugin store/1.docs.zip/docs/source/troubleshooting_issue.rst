Troubleshooting an Issue
########################

When using any application, it's possible to encounter issues or problems that can prevent it from functioning as intended.
These issues may range from minor annoyances to major bugs that can significantly impact the user experience.
As a user of the application, it's important to report these issues to the developers so that they can be addressed and fixed.

Overall, reporting issues is a crucial part of the software development process, and it helps to ensure that applications are reliable,
functional, and user-friendly. Such as issues an found below:

Application Installation
========================

If you encounter problems with some libraries (requirement.txt) such as some libraries that cannot be installed on
the computer, as shown in the image below:

.. figure:: issue/pyqt6.png
   :scale: 60 %
   :alt: alternate text
   :align: center

   PyQt6 cannot installation

.. figure:: issue/sphinx_rtd_theme.png
   :scale: 40 %
   :alt: alternate text
   :align: center

   Sphinx-rtd-theme incompatible (Theme)

We recommend creating a specific virtual environment. Like the following.

.. code-block:: console

   $ sudo apt-get install python3.9-venv​

   $ python3.9 -m venv venv​

   $ source venv/bin/activate​

.. code-block:: console

    $ pip --version

Screen Recording on Application
===============================

That is a difficulty when utilizing MoilApps screen recording functions because the captured video can only be seen as a
black layer and cannot be played back. You may fix it, though, by following the instructions below.

.. figure:: issue/wayland.png
   :scale: 60 %
   :alt: alternate text
   :align: center

   Wayland type screen

Command to check type security screen

.. code-block:: console

   $ echo $XDG_SESSION_TYPE

.. figure:: issue/custom_config.png
   :scale: 60 %
   :alt: alternate text
   :align: center

   open configuration

Command to open custom configuration

.. code-block:: console

   $ sudo nano /etc/gdm3/custom.config

.. figure:: issue/change_type.png
   :scale: 60 %
   :alt: alternate text
   :align: center

   Change to waylandEnable=False

.. figure:: issue/restart.png
   :scale: 60 %
   :alt: alternate text
   :align: center

   Restart your computer

Command for restart your computer

.. code-block:: console

   $ sudo systemctl restart gdm3

Python.h Missing on Python-dev
==============================

When attempting to use MoilCV and running into installation issues with pybind, you can install python-dev using
the appropriate version of Python. Similar to the guidelines below.

.. code-block:: console

   $ sudo apt-get install python3.8-dev

or

.. code-block:: console

   $ sudo apt-get install python3.9-dev

.. figure:: issue/python_dev.png
   :scale: 60 %
   :alt: alternate text
   :align: center

   Python-dev installed based on version

Sphinx Documentation for PDF
=============================

When trying to read the MoilApp documentation by opening it in PDF format, users frequently run into issues that
prevent them from being able to do so because the conversion of rst to html failed. For this reason,

.. figure:: issue/sphinx_PDF.png
   :scale: 60 %
   :alt: alternate text
   :align: center

   Convert rst file to html file

If the following error occurs, we advise installing an additional library so that it can be converted properly.

Command for install library

.. code-block:: console

   $ sudo apt install latexmk

   $ sudo apt install textlive-latex-extra

Command for generate file

.. code-block:: console

   $ make html

   $ make latexpdf

and for  remove file

.. code-block:: console

   $ make clean

Application running
====================

You cannot update the application when an update notification is there when you establish a new branch and add some
functions or alter the source code. You will encounter an error and a dump if you try this.

.. figure:: issue/change_branch.png
   :scale: 60 %
   :alt: alternate text
   :align: center

   check for update on local branch

You first store your files locally because of this.

.. code-block:: console

   $ git stash save "Save comment in local computer"

and then

.. code-block:: console

   $ git checkout "develop/main"

adjustment of name your branch want to change

References
===========

    - `Specific python | How to install pip for Python 3.9 <https://stackoverflow.com/questions/65644782/how-to-install-pip-for-python-3-9-on-ubuntu-20-04>`_

    - `Python.h missing on | with python-dev installed <https://stackoverflow.com/questions/65743603/python-h-missing-on-ubuntu-18-with-python-dev-installed>`_

