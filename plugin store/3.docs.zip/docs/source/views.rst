Views Package
=============

Main Views
--------------------------

.. automodule:: views.main_moilapp
   :members:
   :undoc-members:
   :show-inheritance:

Ui_splash_screen View
-------------------------------

.. automodule:: views.ui_splash_screen
   :members:
   :undoc-members:
   :show-inheritance:
