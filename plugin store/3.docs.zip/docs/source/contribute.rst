How to Contribute
#################

Please follow these steps to contribute a project from your repository to the MoilApp repository.

GitHub Operation
==============

Fork Repository
---------------

Note the name of the repository that you will share into your GitHub, then fork in the upper right corner,
then make sure to check copy main only before you create a fork in your GItHub.

.. figure:: contribute/1.contribute.png
   :scale: 60 %
   :alt: alternate text
   :align: center

   Fork the repository

Clone Repository
----------------

Make careful to create a new branch under the develop branch after cloning the MoilApp repository.
By doing this, you can prevent conflicts between the changes you make in your branch and the updates to the develop
branch in the original repository.

.. figure:: contribute/2.clone-config.png
   :scale: 60 %
   :alt: alternate text
   :align: center

   Clone the repository

Create Virtual Environment
--------------------------

After the repository cloning is complated open the project folder using Pycharm, then press Ctrl + ALT + S,
this function is used to create a virtual environment configuration before you install the requirement library.
Pay attention to each step below to create an environment in your local project so that the application runs according
to requirements.

.. figure:: contribute/3.venv-installation.png
   :scale: 60 %
   :alt: alternate text
   :align: center

   Setting virtual environment & Installation requirements

Pull Request your Project
--------------------------

Once your changes are pushed to the remote repository, you can create a pull request to ask manager to review your changes
and merge them into the main branch. To create a pull request, follow these steps:

Navigate to the repository on GitHub where you pushed your branch.
 - Click on the "Pull request" tab.
 - Click on the "New pull request" button.

Select branch you rant to merge into the main branch. Review the changes you made and add any comments or descriptions that
would be helpful for other team members. Then click on the "Create pull request" button.


Make a Contribute on the Project
================================



