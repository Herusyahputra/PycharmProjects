Plugin Extention
################

Introduction
============

Because the applications are very diverse, we implement a plugin framework so that users can select apps according
to their needs. A plugin is a software component that adds a specific feature to an existing computer program.
When a program supports plug-ins, it enables customization. A plugin architecture consists of two components:
a core system and plug-in modules. The main key design here is to allow adding additional features that are called
plugins modules to our core system, providing extensibility, flexibility, and isolation to our application features.
This will provide us with the ability to add, remove, and change the behavior of the application with little or
no effect on the core system or other plug-in modules making our code very modular and extensible.

.. figure:: plugin-extention/1.plugin-arc.png
   :scale: 85 %
   :alt: alternate text
   :align: center

   Design Moilapp Plugin

Action Plugin
-------------

The MoilApp application is designed to implement this plugin concept, there is a menu bar and a dedicated button
container to control the plug-in application as shown below.


  - Adding a plugin app

    You can add a plugin application that you have created by entering the apps folder into the plugin on the controller.
    If your app fits the format and is successfully added, the plugin app will be available and ready to run.

  - Installing the app

    You can use the plugin store icon to install the provided application.

  - Opening the plugin application

    You can open the plugin you have installed by selecting it in the combo box and pressing the open plugins button.

  - Deleting a plugin app

    If you want to delete a plugin application, you can do so by pressing the "delete" button on the plugin controller
    container. This will open a dialog to confirm that you are sure to delete this application. If the application is
    deleted, it will no longer be available in the application combo box list.

GitHub Operation
================

Before the user creates a new application from the MoilApp plugin, the user must create a fork on the personal GitHub,
this is useful so that the user can easily publish the new application from the local branch to the repository group.

Fork Repository
---------------

Note the name of the repository you visited then, please fork this repository to share it to your GitHub repository.

.. figure:: plugin-extention/7.fork.png
   :scale: 50 %
   :alt: alternate text
   :align: center

   Fork the repository

Create New Branch
-----------------

After you clone the Moilapp repository, make sure to create a new branch under the develop branch,
this is so that what you do to the changes in your branch does not interfere with the develop branch when you update the develop branch in the original repository.

.. figure:: plugin-extention/8.new-branch.png
   :scale: 50 %
   :alt: alternate text
   :align: center

   Create new branch on your branch

Create Plugin Application
=========================

Building a new application with an API involves creating a software program that communicates with an API
(Application Programming Interface) to exchange data and perform various functions. APIs are a set of protocols and tools that allow different software applications to communicate with each other.

Design User Interface
---------------------

To build an application first you create a user interface design using Qt Designer, if your computer has not installed
this tool please install it first. After you create a design on the application user interface you must convert the *.ui file to *.py refer to the next.

.. figure:: plugin-extention/2.create-user-interface.png
   :scale: 50 %
   :alt: alternate text
   :align: center

   Create User Interface

Plugin Interface (API)
-----------------------

It is a plugin interface which is an application program interface (API) that bridges between the main application and the plugin widget.
You can create all the user interfaces you want in your plugin app
You can also use models from the main app, so you don't have to create from scratch.

.. figure:: plugin-extention/3.api.png
   :scale: 55 %
   :alt: alternate text
   :align: center

   Plugin Interface (API)

How to Add an Icon on Moilapp Plugin
-------------------------------------

Import plugin_interface in the controller file, this is so that the plugin interface (API) can be called in the class,
create a set_icon_apps function by returning the name of the icon file that you will use as instructed below.

.. figure:: plugin-extention/4.add-icon.png
   :scale: 60 %
   :alt: alternate text
   :align: center

   Add icon on Moilapp

How to Open Image on User Interface
-----------------------------------

Import Ui_form so that the python file that you have converted from *.ui to *.py can be integrated into a python
function such as the class attribute integrated in the python function below.

.. figure:: plugin-extention/5.add-image-ui.png
   :scale: 55 %
   :alt: alternate text
   :align: center

   Add action push button to load image

Showing on User Interface (Hello World)
------------------------------------------

Operate the simple program that has been created previously to ensure that the program created is in accordance
with what you deisgn on the user interface as shown in the user interface below.

.. figure:: plugin-extention/6.show-ui.png
   :scale: 50 %
   :alt: alternate text
   :align: center

   Show in user interface

Publish Your Project
====================

Refer to the User Operation section to understand more details about the repository project.

Push your Project to GitHub
---------------------------

Before publishing the project, you must make your project in "*.zip" form, where the contents of the file do not have
files such as pycache, ideas and others. Then to upload your project several terminal commands that you use such as

.. code-block:: bash

    git add .
    git commit -m "commit your project"
    git push -u origin "your branch"

Then do a pull request if you want to merge it into the initial repository, after which manage will review your project
and confirm the project is approved for merging or revision.

.. figure:: plugin-extention/9.push.png
   :scale: 60 %
   :alt: alternate text
   :align: center

   Push your project on repository


Tutorial Develop Apps use MoilApp
=================================
.. raw:: html

   <iframe width="680" height="315" src="https://www.youtube.com/embed/9ezABhEVs78" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>


Note Information
----------------

- If you want to create your own plugin application, you can follow the tutorial in section 6.2.
- Tutorial how to operate MoilApp can watch here: https://youtu.be/irpWmNmgAz4
- Suppose you have any issue or want to contribute to this project, you can open issue in GitHub repository and you can ask for pull request.

